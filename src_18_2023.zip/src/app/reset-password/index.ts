export * from './reset-password.component';
export * from './reset-password.module';
