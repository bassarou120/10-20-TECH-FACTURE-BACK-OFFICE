import {Component} from '@angular/core';

@Component({
    selector: 'reset-password',
    templateUrl: './reset-password.component.html',
    styleUrls: ['./reset-password.component.styl']
})
export class ResetPasswordComponent {
    
}
