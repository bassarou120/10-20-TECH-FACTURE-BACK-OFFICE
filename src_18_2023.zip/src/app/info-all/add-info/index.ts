export * from './add-info.component';
export * from './add-info.module';
