import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ListDemandVoyageComponent} from './list-demand-voyage.component';

@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [
       // ListDemandVoyageComponent
    ],
    exports: [
       // ListDemandVoyageComponent
    ]
})
export class ListDemandVoyageModule {}
