export * from './detail-reclamation.component';
export * from './detail-reclamation.module';
