import { Trending } from './trending';

describe('Trending', () => {
  it('should create an instance', () => {
    expect(new Trending()).toBeTruthy();
  });
});
