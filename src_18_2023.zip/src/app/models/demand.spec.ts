import { Demand } from '../models/demand';

describe('Demand', () => {
  it('should create an instance', () => {
    expect(new Demand()).toBeTruthy();
  });
});
