export * from './detail-demand-voyage.component';
export * from './detail-demand-voyage.module';
