import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {DetailDemandVoyageComponent} from './detail-demand-voyage.component';

@NgModule({
    imports: [
        CommonModule,
    ],
    declarations: [
        //DetailDemandVoyageComponent
    ],
    exports: [
       // DetailDemandVoyageComponent
    ]
})
export class DetailDemandVoyageModule {}
