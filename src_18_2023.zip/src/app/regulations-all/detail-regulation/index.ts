export * from './detail-regulation.component';
export * from './detail-regulation.module';
