export * from './add-regulation.component';
export * from './add-regulation.module';
