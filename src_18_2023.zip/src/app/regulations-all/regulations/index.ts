export * from './regulations.component';
export * from './regulations.module';
