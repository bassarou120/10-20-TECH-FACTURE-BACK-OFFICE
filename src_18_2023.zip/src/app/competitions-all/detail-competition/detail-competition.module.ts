import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {DetailCompetitionComponent} from './detail-competition.component';

// @NgModule({
//     imports: [
//         CommonModule
//     ],
//     declarations: [
//         DetailCompetionComponent
//     ],
//     exports: [
//         DetailCompetionComponent
//     ]
// })
export class DetailCompetitionModule {}
