export * from './add-competition.component';
export * from './add-competition.module';
