import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AddCompetitionComponent} from './add-competition.component';

// @NgModule({
//     imports: [
//         CommonModule
//     ],
//     declarations: [
//         AddCompetionComponent
//     ],
//     exports: [
//         AddCompetionComponent
//     ]
// })
export class AddCompetitionModule {}
