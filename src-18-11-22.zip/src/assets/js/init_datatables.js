
$(document).ready(function() {
    var table= $('.datatable').DataTable();
    table.draw();

});