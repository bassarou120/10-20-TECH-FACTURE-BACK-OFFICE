import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {DetailInfoComponent} from './detail-info.component';

// @NgModule({
//     imports: [
//         CommonModule
//     ],
//     declarations: [
//         DetailRegulationComponent
//     ],
//     exports: [
//         DetailRegulationComponent
//     ]
// })
export class DetailInfoModule {}
