import {Component} from '@angular/core';

@Component({
    selector: 'detail-info',
    templateUrl: './detail-info.component.html',
    styleUrls: ['./detail-info.component.styl']
})
export class DetailInfoComponent {
    
}
