export * from './infos.component';
export * from './infos.module';
