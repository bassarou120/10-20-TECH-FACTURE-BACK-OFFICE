import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {InfosComponent} from './infos.component';

// @NgModule({
//     imports: [
//         CommonModule
//     ],
//     declarations: [
//         InfosComponent
//     ],
//     exports: [
//         InfosComponent
//     ]
// })
export class InfosModule {}
