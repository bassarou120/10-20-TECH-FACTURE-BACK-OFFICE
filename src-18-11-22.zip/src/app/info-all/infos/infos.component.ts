import {Component,OnInit} from '@angular/core';

@Component({
    selector: 'app-infos',
    templateUrl: './infos.component.html',
    styleUrls: ['./infos.component.styl']
})
export class InfosComponent implements OnInit  {
    constructor() { }
    ngOnInit() {
    }
}