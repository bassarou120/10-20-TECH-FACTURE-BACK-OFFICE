import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AddCompetionComponent} from './add-competion.component';

// @NgModule({
//     imports: [
//         CommonModule
//     ],
//     declarations: [
//         AddCompetionComponent
//     ],
//     exports: [
//         AddCompetionComponent
//     ]
// })
export class AddCompetionModule {}
