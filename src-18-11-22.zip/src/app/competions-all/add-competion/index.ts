export * from './add-competion.component';
export * from './add-competion.module';
