import {Component} from '@angular/core';
@Component({
    selector: 'add-competion',
    templateUrl: './add-competion.component.html',
    styleUrls: ['./add-competion.component.styl']
})
export class AddCompetionComponent {
    
    
}
