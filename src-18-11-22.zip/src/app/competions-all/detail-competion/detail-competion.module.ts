import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {DetailCompetionComponent} from './detail-competion.component';

// @NgModule({
//     imports: [
//         CommonModule
//     ],
//     declarations: [
//         DetailCompetionComponent
//     ],
//     exports: [
//         DetailCompetionComponent
//     ]
// })
export class DetailCompetionModule {}
