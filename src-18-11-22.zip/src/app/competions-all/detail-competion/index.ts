export * from './detail-competion.component';
export * from './detail-competion.module';
