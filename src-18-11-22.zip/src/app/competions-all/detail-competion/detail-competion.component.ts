import {Component} from '@angular/core';

@Component({
    selector: 'detail-competion',
    templateUrl: './detail-competion.component.html',
    styleUrls: ['./detail-competion.component.styl']
})
export class DetailCompetionComponent {
    
}
