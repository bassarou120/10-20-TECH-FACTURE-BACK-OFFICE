import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {CompetionsComponent} from './competions.component';

// @NgModule({
//     imports: [
//         CommonModule
//     ],
//     declarations: [
//         CompetionsComponent
//     ],
//     exports: [
//         CompetionsComponent
//     ]
// })
export class CompetionsModule {}
