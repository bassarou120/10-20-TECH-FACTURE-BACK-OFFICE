import {Component} from '@angular/core';

@Component({
    selector: 'competions',
    templateUrl: './competions.component.html',
    styleUrls: ['./competions.component.styl']
})
export class CompetionsComponent {
    
}
