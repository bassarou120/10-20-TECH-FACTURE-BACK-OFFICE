export * from './competions.component';
export * from './competions.module';
