import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {InvestorsComponent} from './investors.component';

// @NgModule({
//     imports: [
//         CommonModule
//     ],
//     declarations: [
//         InvestorsComponent
//     ],
//     exports: [
//         InvestorsComponent
//     ]
// })
export class InvestorsModule {}
