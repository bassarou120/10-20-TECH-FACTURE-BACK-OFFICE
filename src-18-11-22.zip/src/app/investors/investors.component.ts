import {Component,OnInit} from '@angular/core';

@Component({
    selector: 'app-investors',
    templateUrl: './investors.component.html',
    styleUrls: ['./investors.component.styl']
})
export class InvestorsComponent implements OnInit  {
    constructor() { }
    ngOnInit() {
    }
}
