import { Regulation } from './regulation';

describe('Regulation', () => {
  it('should create an instance', () => {
    expect(new Regulation()).toBeTruthy();
  });
});
