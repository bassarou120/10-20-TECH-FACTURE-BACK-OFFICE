import { Job } from "./job"

export class Complaints {
    id: number
    firstname: string
    lastname: string
    email: string
    phone_number: string
    relative_contact: string
    objet: string
    complaint: string
    actor: string
    statut: string
    action: string
    created_at: string
    updated_at: string

    job: Job

    constructor(
        firstname: string,
        lastname: string,
        email: string,
        phone_number: string,
        relative_contact: string,
        objet: string,
        complaint: string,
        actor: string,
        statut: string,
        action: string,
      
    ) {
        this.firstname = firstname
        this.lastname = lastname
        this.email = email
        this.phone_number = phone_number
        this.relative_contact = relative_contact
        this.objet = objet
        this.complaint = complaint
        this.actor = actor
        this.statut = statut
        this.action = action
    }
}
