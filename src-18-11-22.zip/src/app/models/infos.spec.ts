import { Infos } from './infos';

describe('Infos', () => {
  it('should create an instance', () => {
    expect(new Infos()).toBeTruthy();
  });
});
