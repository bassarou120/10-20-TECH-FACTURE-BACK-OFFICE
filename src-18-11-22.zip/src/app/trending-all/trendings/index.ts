export * from './trendings.component';
export * from './trendings.module';
