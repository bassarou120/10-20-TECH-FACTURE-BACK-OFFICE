export * from './add-trending.component';
export * from './add-trending.module';
