export * from './faq.component';
export * from './faq.module';
