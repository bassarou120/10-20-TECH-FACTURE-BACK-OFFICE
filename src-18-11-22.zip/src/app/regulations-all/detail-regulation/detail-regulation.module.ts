import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {DetailRegulationComponent} from './detail-regulation.component';

// @NgModule({
//     imports: [
//         CommonModule
//     ],
//     declarations: [
//         DetailRegulationComponent
//     ],
//     exports: [
//         DetailRegulationComponent
//     ]
// })
export class DetailRegulationModule {}
