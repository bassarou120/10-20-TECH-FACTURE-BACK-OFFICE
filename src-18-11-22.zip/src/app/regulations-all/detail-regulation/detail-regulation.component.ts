import {Component} from '@angular/core';

@Component({
    selector: 'detail-regulation',
    templateUrl: './detail-regulation.component.html',
    styleUrls: ['./detail-regulation.component.styl']
})
export class DetailRegulationComponent {
    
}
