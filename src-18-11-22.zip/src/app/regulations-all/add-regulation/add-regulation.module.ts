import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AddRegulationComponent} from './add-regulation.component';
import { NgxQuillModule } from '@dimpu/ngx-quill';
import { FormsModule } from '@angular/forms';

// @NgModule({
//     imports: [
//         CommonModule,
//         NgxQuillModule,
//         FormsModule
//     ],
//     declarations: [
//         // AddRegulationComponent
//     ],
//     exports: [
//         // AddRegulationComponent
//     ]
// })
export class AddRegulationModule {}
 