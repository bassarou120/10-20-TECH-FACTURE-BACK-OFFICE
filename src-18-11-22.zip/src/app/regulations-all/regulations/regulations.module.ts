import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RegulationsComponent} from './regulations.component';

// @NgModule({
//     imports: [
//         CommonModule
//     ],
//     declarations: [
//         RegulationsComponent
//     ],
//     exports: [
//         RegulationsComponent
//     ]
// })
export class RegulationsModule {}
