export * from './detail-complaint.component';
export * from './detail-complaint.module';
