import { Injectable } from '@angular/core';
import {environment} from '../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import { Complaints } from 'app/models/complaints';

@Injectable({
  providedIn: 'root'
})
export class ComplaintsService {

  url: string = environment.backend + '/complaints';
  url_by_job = environment.backend+ '/job/';

  constructor(private http: HttpClient) { }

  // Enregistrement d'un element
  save(complaints: Complaints,id:number): Observable<Object> {
    return this.http.post(`${this.url_by_job}/${id}/complaints`, complaints);
  }
   // Modification d'un element
  edit(complaints: Complaints,id: number): Observable<Object> {
    return this.http.put(`${this.url}/${id}`, complaints);
  }

  // change statut d'un element
  changeStatut(id: number): Observable<Object> {
    return this.http.put(`${this.url}/changestatut/${id}`,'');
  }

  // Supression d'un element'
  delete(id:number): Observable<Object> {
    return this.http.delete(`${this.url}/${id}`);
  }

  // liste des elements
  list(): Observable<Object> {
    return this.http.get(`${this.url}`);
  }

  // liste des IDE par id
  getById(id: number): Observable<Object> {
    return this.http.get(`${this.url}/${id}`);
  }
}
