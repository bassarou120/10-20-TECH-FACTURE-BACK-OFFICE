import { Injectable } from '@angular/core';
import {environment} from '../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Job} from '../models/job';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class JobService {

  url: string = environment.backend + '/jobs';

  constructor(private http: HttpClient) { }

    // liste des FAq
    list(): Observable<Object> {
      return this.http.get(`${this.url}`);
    }
  
}
