import { Injectable } from '@angular/core';
import {environment} from '../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Competition} from '../models/competition';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CompetitionService {

  url: string = environment.backend + '/competitions';

  constructor(private http: HttpClient) { }

  // Enregistrement d'un element
  save(competition: Competition): Observable<Object> {
    return this.http.post(`${this.url}`, competition);
  }

  // Modification d'un element
  edit(competition: Competition,id: number): Observable<Object> {
    return this.http.put(`${this.url}/${id}`, competition);
  }

  // Supression d'un element 
  delete(id: number): Observable<Object> {
    return this.http.delete(`${this.url}/${id}`);
  }

  // liste des Competitons
  list(): Observable<Object> {
    return this.http.get(`${this.url}`);
  }

  // liste des IDE par id
  getById(id: number): Observable<Object> {
    return this.http.get(`${this.url}/${id}`);
  }
}
