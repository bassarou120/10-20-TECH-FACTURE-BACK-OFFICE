export * from './reclamations.component';
export * from './reclamations.module';
