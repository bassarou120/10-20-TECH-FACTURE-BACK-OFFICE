export * from './detail-info.component';
export * from './detail-info.module';
