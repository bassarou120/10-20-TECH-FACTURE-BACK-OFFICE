
export class Role {
  id: number;
  name: string;
  libelle: string;

  constructor(id: number, name: string, libelle: string) {
    this.id = id;
    this.name = name;
    this.libelle = libelle;
  }
}
