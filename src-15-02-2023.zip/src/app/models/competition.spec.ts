import { Competition } from './competition';

describe('Competition', () => {
  it('should create an instance', () => {
    expect(new Competition()).toBeTruthy();
  });
});
