import { Complaints } from './complaints';

describe('Complaints', () => {
  it('should create an instance', () => {
    expect(new Complaints()).toBeTruthy();
  });
});
