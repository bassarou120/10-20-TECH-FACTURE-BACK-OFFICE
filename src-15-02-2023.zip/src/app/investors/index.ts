export * from './investors.component';
export * from './investors.module';
