export class Header {
 title: string;
 explain: string;

 constructor(title: string, explain: string) {
    this.title = title;
    this.explain = explain;
  }
}
