export class ResetAccount {

  email: string;

  baseLien: string;

  constructor(email: string, baseLien: string) {
    this.email = email;
    this.baseLien = baseLien;
  }
}
