export class Duree {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;

  constructor(days: number, hours: number, minutes: number, seconds: number) {
    this.days = days;
    this.hours = hours;
    this.minutes = minutes;
    this.seconds = seconds;
  }
}
