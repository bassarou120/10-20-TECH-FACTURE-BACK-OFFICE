export class ResetPassword {

  newPassword: string;

  constructor(newPassword: string) {
    this.newPassword = newPassword;
  }

}
