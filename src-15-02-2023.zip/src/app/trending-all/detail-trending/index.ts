export * from './detail-trending.component';
export * from './detail-trending.module';
