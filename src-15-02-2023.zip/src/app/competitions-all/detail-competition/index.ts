export * from './detail-competition.component';
export * from './detail-competition.module';
