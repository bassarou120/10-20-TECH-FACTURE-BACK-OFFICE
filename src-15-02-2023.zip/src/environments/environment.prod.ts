export const environment = {
  production: true,
  backend: "https://tourisme-api.herokuapp.com/api/v1",

  ssoUrlCallback: "https://tourisme-app.star-labs.bj/admin/sso_callback",
  // ssoUrlCallback: "https://pprodofficial.service-public.bj/official/login?client_id=mtcalicence&redirect_uri=http://tourisme-app.star-labs.bj/admin/sso_callback&response_type=code&scope=openid&authError=true",
  expirationTime: 0
};
